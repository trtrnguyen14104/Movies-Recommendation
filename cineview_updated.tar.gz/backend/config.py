from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    TMDB_API_KEY: str = ""
    GEMINI_API_KEY: str = ""
    TMDB_BASE_URL: str = "https://api.themoviedb.org/3"
    TMDB_IMAGE_BASE: str = "https://image.tmdb.org/t/p"

    # ChromaDB Cloud
    CHROMADB_API_KEY: str = "ck-GfacYicGMavutK6PBMVz4pVSiYd3n3bKJvQeKhY1zekj"
    CHROMADB_TENANT: str = "0a72f098-6d39-4bfb-8bfe-d406e88c2139"
    CHROMADB_DATABASE: str = "MovieRecommend"

    class Config:
        env_file = ".env"

settings = Settings()
